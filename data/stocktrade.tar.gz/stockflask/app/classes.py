class Prices():
    date = ""
    open = ""
    high = ""
    low = ""
    close = ""

class Inner:
    condition = ""
    high = ""
    low = ""
    date =""


